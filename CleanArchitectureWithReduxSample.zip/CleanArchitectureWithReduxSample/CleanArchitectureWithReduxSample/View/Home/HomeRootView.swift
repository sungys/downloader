//
//  HomeRootView.swift
//  CleanArchitectureWithReduxSample
//
//  Created by JarvanSun on 2021/6/24.
//

import SwiftUI

struct HomeRootView: View {
    var body: some View {
        NavigationView {
            HomeView().navigationBarTitle("Home")
        }
    }
}

struct HomeRootView_Previews: PreviewProvider {
    static var previews: some View {
        HomeRootView()
    }
}
