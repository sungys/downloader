//
//  SettingRootView.swift
//  CleanArchitectureWithReduxSample
//
//  Created by JarvanSun on 2021/6/24.
//

import SwiftUI

struct SettingRootView: View {
    var body: some View {
        NavigationView {
            SettingView().navigationBarTitle("Settings")
        }
    }
}

struct SettingRootView_Previews: PreviewProvider {
    static var previews: some View {
        SettingRootView()
    }
}
