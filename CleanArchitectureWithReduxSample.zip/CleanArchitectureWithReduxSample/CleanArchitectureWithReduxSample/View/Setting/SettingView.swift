//
//  SettingView.swift
//  CleanArchitectureWithReduxSample
//
//  Created by JarvanSun on 2021/6/24.
//

import SwiftUI

struct SettingView: View {
    @State var isLoggedIn = false
    @State var email: String = ""
    @State var password: String = ""
    @State var loginRequesting = false
    
    var body: some View {
        Form {
            accountSection
            optionSection
            actionSection
        }
    }
    
    var accountSection: some View {
        Section(header: Text("Account")) {
            if !isLoggedIn {
                TextField("Email", text: $email)
                SecureField("Password", text: $password)
                if loginRequesting {
                    Text("Loading...")
                } else {
                    Button("Sign in") {
                        // TODO
                    }
                }
            } else {
                Text(email)
                Button("Sign out") {
                    // TODO
                }
            }
        }
    }
    
    var optionSection: some View {
        Section(header: Text("Option")) {
            
        }
    }
    
    var actionSection: some View {
        Section {
            Button(action: {
                print("Clear Cache")
            }) {
                Text("Clear Cache").foregroundColor(.red)
            }
        }
    }
}

struct SettingView_Previews: PreviewProvider {
    @State static var email = "test"
    static var previews: some View {
        SettingView()
    }
}
