//
//  MainTab.swift
//  CleanArchitectureWithReduxSample
//
//  Created by JarvanSun on 2021/6/24.
//

import SwiftUI

struct MainTab: View {
    var body: some View {
        TabView {
            HomeRootView().tabItem {
                Image(systemName: "house")
                Text("Home")
            }
            SettingRootView().tabItem {
                Image(systemName: "gear")
                Text("Setting")
            }
        }
        .edgesIgnoringSafeArea(.top)
    }
}

struct MainTab_Previews: PreviewProvider {
    static var previews: some View {
        MainTab()
    }
}
